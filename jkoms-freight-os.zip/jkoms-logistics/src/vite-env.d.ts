/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_SUPABASE_URL: string;
  readonly VITE_SUPABASE_ANON_KEY: string;
  readonly VITE_COMPANY_NAME?: string;
  readonly VITE_COMPANY_SHORT_CODE?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
